#!/bin/bash

export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:./"

./z-enemy -a x16r -o stratum+tcp://raven.f2pool.com:3636 -u RNpeu9qTN75KQP6wd12fZVmNoCkLGaff78.default -p x
